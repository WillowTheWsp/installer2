## Changelog

### v1.5.1
- Fixed file paths

### v1.5.0
- Add [130 new filled icons](https://telegra.ph/Reserved-06-27 "New icons for version 1.5.0") by [TeamFiles](https://t.me/modulesrepo "Modules Repository | Team Files™")

### v1.4.0
- Add [24 new filled icons](https://telegra.ph/Reserved-06-01 "New icons for version 1.4.0") by [TeamFiles](https://t.me/modulesrepo "Modules Repository | Team Files™")

### v1.3.0
- Fixed strange bug in v1.2.0 that did not allow flashing the module
- Add [15 new filled icons](https://telegra.ph/New-icons-for-version-130-05-11 "New icons for version 1.3.0") by [TeamFiles](https://t.me/modulesrepo "Modules Repository | Team Files™")

### v1.2.0
- Add [28 new filled icons](https://telegra.ph/Reserved-05-09 "New icons for version 1.2.0") by [TeamFiles](https://t.me/modulesrepo "Modules Repository | Team Files™")

### v1.1.0
- Add [20 new filled icons](https://telegra.ph/Reserved-04-14 "New icons for version 1.1.0") by [TeamFiles](https://t.me/modulesrepo "Modules Repository | Team Files™")
- Optimized zip space

### v1.0.1
- Fixed conflict with Pixel Experience Plus v412 themed icons.

### v1.0.0
- Initial Build
- 644 Filled Icons by [TeamFiles](https://t.me/modulesrepo "Modules Repository | Team Files™")
- 295 Line Icons by [Lawnchair Team](https://github.com/LawnchairLauncher/lawnicons "Lawnchair News")