## Changelog

- Added KernelSU Support
- Fixed ML Algorithm
- Fixed Frequency Scaling
- Fixed Config Interpreter
- Fixed Refresh Rate on Boot
- Fixed Installation on Other Managers
- Updated Module Updater to v4.0
- Miscellaneous Fixes and Improvements
